<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\ModelNilai;

class Nilai extends BaseController
{
    use ResponseTrait;
    function __construct()
    {
        $this->model = new ModelNilai();
    }
    public function index()
    {
        $data = $this->model->orderBy('npm', 'asc')->findAll();
        return $this->respond($data, 200);
    }
    public function show($id_nilai = null)
    {
        $data = $this->model->where('id_nilai', $id_nilai)->findAll();
        if($data){
            return $this->respond($data,200);
        }else{
            return $this->failNotFound("data tidak ditemukan untuk id_nilai $id_nilai");
        }
    }
    public function create()
    {
        $data = $this->request->getPost();

        if (!$this->model->save($data)) {
            return $this->failValidationErrors($this->model->errors());
        }

        $response = [
            'status' => 201,
            'error' => null,
            'messages' => [
                'success' => 'Berhasil memasukkan data mahasiswa'
            ]
        ];
        return $this->respondCreated($response);
    }
    public function update($id_nilai = null)
    {
        $data = $this->request->getRawInput();
        $data['id_nilai'] = $id_nilai;
    
        // Pastikan data dengan NPM ada sebelum update
        $isExists = $this->model->where('id_nilai', $id_nilai)->first();
        if (!$isExists) {
            return $this->failNotFound("Data tidak ditemukan untuk id_nilai $id_nilai");
        }
    
        // Gunakan update() dengan where()
        if ($this->model->where('id_nilai', $id_nilai)->set($data)->update()) {
            return $this->respond([
                'status' => 200,
                'error' => null,
                'messages' => [
                    'success' => "Data mahasiswa dengan id_nilai $id_nilai berhasil diperbarui"
                ]
            ]);
        }
    
        return $this->fail("Gagal mengupdate data mahasiswa.");
    }
    
    public function delete($id_nilai)
    {
        $data = $this->model->where('id_nilai', $id_nilai)->findAll();
        
        if ($data) {
            $this->model->where('id_nilai', $id_nilai)->delete(); // Perbaikan metode delete()
    
            $response = [
                'status' => 200,
                'error' => null,
                'messages' => [
                    'success' => "Data dengan id_nilai $id_nilai berhasil dihapus"
                ]
            ];
            return $this->respond($response); // Perbaikan dari responddelete()
        } else {
            return $this->failNotFound("Data dengan id_nilai $id_nilai tidak ditemukan");
        }
    }
}    