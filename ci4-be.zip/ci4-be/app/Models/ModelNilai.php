<?php
namespace App\Models;

use CodeIgniter\Model;

class ModelNilai extends Model
{
    protected $table = "nilai";
    protected $primarykey = "id_nilai";
    protected $allowedFields = ['npm', 'kode_matkul', 'nidn', 'tugas', 'uts', 'uas', 'nilai_akhir', 'status'];
    
    protected $validationRules = [
        'id_nilai' =>'required',
        'npm' =>'required',
        'kode_matkul' =>'required',
        'nidn' =>'required',
        'tugas' =>'required',
        'uts' =>'required',
        'uas' =>'required',
        'nilai_akhir' =>'required',
        'status' =>'required',
       
    ];
    protected $validationMesaages = [
        'id_nilai'=>[
            'required'=>'silahkan masukan id nilai'
        ],
        'npm'=>[
            'required'=>'silahkan masukan npm'
        ],
        'kode_matkul'=>[
            'required'=>'silahkan masukan kode matkul'
        ],
        'nidn'=>[
            'required'=>'silahkan masukan nidn'
        ],
        'tugas'=>[
            'required'=>'silahkan masukan tugas'
        ],
        'uts'=>[
            'required'=>'silahkan masukan uts'
        ],
        'uas'=>[
            'required'=>'silahkan masukan uas'
        ],
        'nilai_akhir'=>[
            'required'=>'silahkan masukan nilai_akhir'
        ],
        'status'=>[
            'required'=>'silahkan masukan status'
        ],
    ];
}
